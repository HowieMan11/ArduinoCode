

#include "SDtester.h"
#include "Arduino.h"
#include <TimeLib.h>
#include <SD.h>

SDtester::SDtester(uint8_t _address){
  address = _address;
  data = 0;
}

bool SDtester::createDataFile(){
  // create a data file 
  //    returns 1 if successful
  //            0 if unsuccessful
  if(!SD.begin(BUILTIN_SDCARD)){
    Serial.println("\tSD init unsuccessful");
    return 0;
  }else{
    Serial.println("\tSD init success");
    // check if the file exists
    if(SD.exists(dataFileName)){
      Serial.println("\tdata log exists");
      return 1;
    }else{
      File f = SD.open(dataFileName, FILE_WRITE);
      f.println("header, header");
      f.close();
      
      Serial.println("data log created");
      return 1;
    }
  }
}

bool SDtester::updateLog(){
  // function up update the log file on SD
  //    returns 1 if successful
  //            0 if unsuccessful

  // attempt to open the sd card;
  Serial.print("writing to "); Serial.print(char(address)); Serial.println(" log");

  if(!SD.begin(BUILTIN_SDCARD)){
    Serial.println("\tSD init unsuccessful");
    return 0;
  }else{
    Serial.println("\tSD init success");
    File f = SD.open(logFileName, FILE_WRITE);

    if(f){
      f.print("address: ");
      f.print(char(address));
      f.print(" - time: ");f.print(year()); f.print("/");
      f.print(month()); f.print("/"); f.print(day());    f.print(" - ");
      f.print(hour());  f.print(":"); f.print(minute()); f.print(" - data: ");
      f.println(data);
      f.close();
      Serial.println("\tfile write success");
      return 1;

    }else{
      Serial.println("\tfile write unsuccessfull");
      return 0;
    }
  }
}

int SDtester::updateData(){
  data++;
  return data;
}


void SDtester::setLogName(){
  // Create the log file name first
  char log_name[11] =  "LOG_#.TXT ";
  for(int i=0; i<9; i++){
    logFileName[i] = log_name[i];
  }
  logFileName[4] = char(address);
}

void SDtester::setDataName(){
  // then the data file
  char data_name[12] =  "DATA_#.TXT ";
  for(int j=0; j<10; j++){
    dataFileName[j] = data_name[j];
  }
  dataFileName[5] = char(address);
}








