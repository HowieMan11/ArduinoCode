#ifndef SDtester_h
#define SDtester_h
#include <Arduino.h>
#include <SD.h>

class SDtester{
  public:
    SDtester(uint8_t _address);
    
    // file recording funcs
    bool createDataFile(); // there's a creat and update for the dat file so we don't get random headers throught the data 
    //bool updateDataFile(); 
    bool updateLog();
    void setLogName();
    void setDataName();

    // getters & setters

    // data handling
    void updateData();

  private:
    uint8_t address;
    char logFileName[10];
    char dataFileName[11];
    int debugLevel; 
    int data;

};

#endif