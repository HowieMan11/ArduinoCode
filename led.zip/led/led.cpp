#include "Arduino.h"
#include "led.h"
#include <timer.h>

led::led(int _pin){
  pin = _pin;
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
  blinkRate = 1000;
  blinkTimer.setInterval(blinkRate);
}

void led::setState(bool s){
  ledState = s;
  digitalWrite(pin, ledState);
}

void led::blink(){
  if(blinkTimer.checkTime()){
    toggle();
  }
}

void led::enable(){
  digitalWrite(pin, HIGH);
  ledState = true;
}

void led::disable(){
  digitalWrite(pin, LOW);
  ledState = false;
}

void led::toggle(){
  if(ledState){
    ledState = false;
  }else{
    ledState = true;
  }
  digitalWrite(pin, ledState);
}

void led::setBlinkRate(int _blinkRate){ 
  blinkRate = _blinkRate; 
  blinkTimer.setInterval(blinkRate);
}

int led::getPin(void){ return pin; }