#ifndef led_h
#define led_h
#include <Arduino.h>
#include <timer.h>

class led{
  public:
    led(int _pin);
    int getPin(void);
    void enable(void);
    void disable(void);
    void toggle(void);
    void blink();
    void setBlinkRate(int _blinkRate);
    void setState(bool s);

  private:
    int pin; // the pin we're connected to
    bool ledState;    
    int blinkRate;
    timer blinkTimer;

};

#endif