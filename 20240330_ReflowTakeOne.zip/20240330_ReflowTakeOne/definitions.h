#include <tftButton.h>
#include <EEPROM.h>
#include "Arduino.h"
#include <timer.h>
#include <Adafruit_GFX.h>
#include <SPI.h>
#include "Adafruit_HX8357.h"
#include "TouchScreen.h"
#include <maxRTD.h>
#include <PID_v1.h>
#include <SD.h>
#include <Adafruit_MAX31865.h>


//Colors
#define backgroundColor 0x5AAB
#define white 0xFFFF
#define black 0x0000
#define red 0xF800
#define buttonColor 0x035F

// Display Things
#define TFT_RST -1  // dont use a reset pin, tie to arduino RST if you like
#define TFT_DC 15
#define TFT_CS 14
// These are the four touchscreen analog pins
#define YP A2  // must be an analog pin, use "An" notation!
#define XM A5  // must be an analog pin, use "An" notation!
#define YM 18   // can be a digital pin
#define XP 17   // can be a digital pin


// heater output Pin
#define outputPin 9
#define RREF 430.0
#define RNOMINAL 100










