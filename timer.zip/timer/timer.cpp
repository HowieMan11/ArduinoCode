#include "Arduino.h"
#include "timer.h"

timer::timer(){
  interval = 1000;
  previousTime = millis();
}

bool timer::checkTime(){
  unsigned long currentTime = millis();
  if(currentTime - previousTime >= interval){
    previousTime = currentTime;
    return true;
  } else {
    return false;
  }
}

void timer::setInterval(int _interval){
  interval = _interval;
}

void timer::reset(void){
  previousTime = millis();
}

unsigned long timer::getInterval(){ return interval;}