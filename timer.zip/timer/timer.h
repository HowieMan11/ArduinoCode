#ifndef timer_h
#define timer_h
#include <Arduino.h>

class timer {
  public:
    timer();
    bool checkTime();
    void setInterval(int _interval);
    void reset();
    unsigned long getInterval();

  private:
    unsigned long interval; // delay time
    unsigned long previousTime;

};
#endif